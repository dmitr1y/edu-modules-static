java -classpath engine.jar ru.spb.ipo.generator.base.startup.startup

