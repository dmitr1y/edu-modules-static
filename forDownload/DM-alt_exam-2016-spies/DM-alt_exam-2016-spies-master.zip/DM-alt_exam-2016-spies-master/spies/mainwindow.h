#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTextEdit>
#include <QHBoxLayout>
#include <QListWidget>
#include <QPushButton>
#include <QList>
#include <QMessageBox>
#include <QLabel>

class Spy
{
public:
    Spy(QList<int *> *keyVariants, int spyNo, int keyPart, int nKeyParts);
    ~Spy();
    int computeConclusions(QList<int *> *publicVariants);
    bool getAnswer(int i);

private:
    int spyNo_;
    int nKeyParts_;
    QList<int *> *keyVariants_;
    int *knownParts_;
    bool *answers_;

protected:

};

class Info : public QWidget
{
    Q_OBJECT

public:
    Info(QWidget *parent=0);
    ~Info();

private:
    QHBoxLayout *mainLayout_;
    QVBoxLayout *leftLayout_;
    QVBoxLayout *tipsLayout_;
    QHBoxLayout **tips_;
    QLabel *about_;
    QLabel *problemFormulation_;
    QLabel **tipLabels_;
    QLabel **tipImages_;

protected:

};

class ActionsList : public QListWidget
{
    Q_OBJECT

public:
    ActionsList(int nKeyParts, QWidget *parent = 0);
    ~ActionsList();
    void addQuestion(int from, int to, bool answer, QList<int *> *deletedVariants, QList<int *> *remainingVariants);
    void addInput(QList<int *> *publicVariants);
    void addFinal(QList<int *> *publicVariants);
    void setNKeyParts(int nKeyParts);

private:
    int nKeyParts_;

private slots:
    void hideInfo(QListWidgetItem *item);

protected:
};

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = 0);
    ~MainWindow();

private:
    int nSpies_;
    Spy **spies_;
    QList<int *> *publicVariants_;
    QWidget *centralWidget_;
    Info *info_;
    ActionsList *actionsList_;
    QHBoxLayout *formsLayout_;
    QVBoxLayout *inputLayout_;
    QHBoxLayout *buttonsLayout_;
    QTextEdit *inputForm_;
    QPushButton *startButton_;
    QPushButton *infoButton_;

    int searchUniquePartsAndAskQuestions();
    int parsePublicVariants();

private slots:
    void computeQuestions();

protected:

};

#endif // MAINWINDOW_H
