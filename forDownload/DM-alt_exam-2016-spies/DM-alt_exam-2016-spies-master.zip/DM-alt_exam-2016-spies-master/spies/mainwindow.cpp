#include "mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    nSpies_ = 0;

    spies_ = NULL;

    publicVariants_ = NULL;

    info_ = new Info;
    info_->show();

    inputForm_ = new QTextEdit;
    inputForm_->setLineWrapMode(QTextEdit::NoWrap);
    inputForm_->setMaximumWidth(350);
    inputForm_->setText("Please, Enter a set of the keys here\nand press start button.\nFirst enter the correct key.\nFor example:\n16 7   <--- the correct key\n15 5\n16 5\n19 5\n17 6\n18 6\n14 7\n14 8\n15 8\n17 8");

    startButton_ = new QPushButton;
    startButton_->setText("START!");
    startButton_->setMaximumWidth(350);
    startButton_->setIcon(QIcon(":/img/start.png"));
    connect(startButton_, SIGNAL(pressed()),  this, SLOT(computeQuestions()));

    infoButton_ = new QPushButton;
    infoButton_->setMaximumWidth(30);
    infoButton_->setIcon(QIcon(":/img/info.png"));
    connect(infoButton_, SIGNAL(pressed()), info_, SLOT(show()));

    buttonsLayout_ = new QHBoxLayout;
    buttonsLayout_->addWidget(startButton_);
    buttonsLayout_->addWidget(infoButton_);

    inputLayout_ = new QVBoxLayout;
    inputLayout_->addWidget(inputForm_);
    inputLayout_->addLayout(buttonsLayout_);

    actionsList_ = new ActionsList(nSpies_);
    connect(actionsList_, SIGNAL(itemClicked(QListWidgetItem*)), actionsList_, SLOT(hideInfo(QListWidgetItem*)));

    formsLayout_ = new QHBoxLayout;
    formsLayout_->addWidget(actionsList_);
    formsLayout_->addLayout(inputLayout_);

    centralWidget_ = new QWidget;
    centralWidget_->setLayout(formsLayout_);

    setWindowTitle("Spies");
    setWindowIcon(QIcon(":/img/logo.png"));
    setCentralWidget(centralWidget_);
    setMinimumWidth(700);
    setMinimumHeight(400);
}

void MainWindow::computeQuestions()
{
    publicVariants_ = new QList<int*>;
    actionsList_->clear();

    /*parsing and checking on errors*/
    if(parsePublicVariants() == 0)
    {
        delete publicVariants_;
        publicVariants_ = NULL;
        return;
    }

    /*copying an original variants to delete them after work*/
    QList<int *> *originalVariants = new QList<int *>(*publicVariants_);

    /*input*/
    actionsList_->addInput(publicVariants_);

    /*spies's analyse*/
    for(int i = 0; i < nSpies_; i++)
        if(spies_[i]->computeConclusions(publicVariants_) == 1) //checking on errors
        {
            QMessageBox *msg = new QMessageBox(QMessageBox::Warning, "Error",
                                               QString("An error occurred while running the program.\n")+
                                               QString("Please, send the entered keys to deligor6321@gmail.com"));
            msg->setWindowIcon(QIcon(":/img/logo.png"));
            msg->show();
            publicVariants_->clear();
        }

    /*main cycle*/
    if(publicVariants_->size() > 1)
    {
        while(searchUniquePartsAndAskQuestions() != 0);
    }

    /*conclusion*/
    actionsList_->addFinal(publicVariants_);

    /*garbage cleaning*/
    if(nSpies_ != 0 || spies_ != NULL)
    {
        for(int i = 0; i < nSpies_; i++)
            delete spies_[i];
        delete spies_;
        nSpies_ = 0;
        spies_ = NULL;
    }
    if(publicVariants_ != NULL)
    {
        publicVariants_->clear();
        delete publicVariants_;
        publicVariants_ = NULL;
    }
    if(originalVariants != NULL)
    {
        for(QList<int *>::iterator i = originalVariants->begin();
            i != originalVariants->end(); i++)
            delete (*i);
        delete originalVariants;
        originalVariants = NULL;
    }
}

MainWindow::searchUniquePartsAndAskQuestions()
{
    bool broke = false;
    int i, j, nQuestions = 0;
    QList<int *>::iterator currentVariant, currentUniqueVariant, currentCommonVariant;
    QList<int *> *uniqueList , *commonList, *deletedList;
    int *newKey;
    for(i = 0; i < nSpies_; i++)
    {
        currentVariant = publicVariants_->begin();
        uniqueList = new QList<int *>;
        commonList = new QList<int *>;
        while(currentVariant != publicVariants_->end())
        {
            newKey = *currentVariant;
            currentUniqueVariant = uniqueList->begin();
            currentCommonVariant = commonList->begin();
            while(currentCommonVariant != commonList->end())
            {
                if((*currentCommonVariant)[i] == newKey[i])
                {
                    commonList->push_back(newKey);
                    break;
                }
                currentCommonVariant++;
            }
            if(currentCommonVariant == commonList->end())
            {
                broke = false;
                if(uniqueList->empty())
                {
                    uniqueList->push_back(newKey);
                }
                else
                {
                    while(currentUniqueVariant != uniqueList->end())
                    {
                        if((*currentUniqueVariant)[i] == newKey[i])
                        {
                            commonList->push_back(*currentUniqueVariant);
                            commonList->push_back(newKey);
                            uniqueList->erase(currentUniqueVariant);
                            broke = true;
                            break;
                        }
                        else
                        {
                            currentUniqueVariant++;
                        }
                    }
                    if(!broke)
                    {
                        uniqueList->push_back(newKey);
                    }
                }
            }
            currentVariant++;
        }
        if(!uniqueList->empty() && !commonList->empty())
        {
            nQuestions++;
            if(spies_[i]->getAnswer(i))
            {
                actionsList_->addQuestion(i+1, i+1, spies_[i]->getAnswer(i), commonList, uniqueList);
                delete publicVariants_;
                delete commonList;
                publicVariants_ = uniqueList;
            }
            else
            {
                actionsList_->addQuestion(i+1, i+1, spies_[i]->getAnswer(i), uniqueList, commonList);
                delete publicVariants_;
                publicVariants_ = commonList;
                for(j = 0; j < nSpies_; j++)
                    if(i != j)
                    {
                        nQuestions++;
                        deletedList = new QList<int *>;
                        if(!spies_[j]->getAnswer(i))
                        {
                            currentUniqueVariant = uniqueList->begin();
                            while(currentUniqueVariant != uniqueList->end())
                            {
                                currentVariant = publicVariants_->begin();
                                while(currentVariant != publicVariants_->end())
                                {
                                    if((*currentVariant)[j] == (*currentUniqueVariant)[j])
                                    {
                                        deletedList->push_back(*currentVariant);
                                        currentVariant = publicVariants_->erase(currentVariant);
                                    }
                                    else
                                    {
                                        currentVariant++;
                                    }
                                }
                                currentUniqueVariant++;
                            }
                        }
                        actionsList_->addQuestion(j+1, i+1, spies_[j]->getAnswer(i), deletedList, publicVariants_);
                        deletedList->clear();
                        delete deletedList;
                        if(publicVariants_->size() == 1)
                        {
                            return 0;
                        }
                    }
                delete uniqueList;
            }
            for(j = 0; j < nSpies_; j++)
                if(spies_[j]->computeConclusions(publicVariants_) == 1)
                {
                    QMessageBox *msg = new QMessageBox(QMessageBox::Warning, "Error",
                                                       QString("An error occurred while running the program.\n")+
                                                       QString("Please, send the entered keys to deligor6321@gmail.com"));
                    msg->setWindowIcon(QIcon(":/img/logo.png"));
                    msg->show();
                    return 0;
                }
            if(publicVariants_->size() == 1)
            {
                return 0;
            }
        }
    }
    return nQuestions;
}

int MainWindow::parsePublicVariants()
{
    QString text = inputForm_->toPlainText();
    QStringList lines = text.split('\n');
    QStringList numbers;
    QList<int *> *newList;
    QList<int *>::iterator currentPublicVariant;
    int *newKey;
    int keyPartNo, lineNo, nVariants = 0;
    if(lines.size() == 0)
        return 0;
    nSpies_ = 0;
    for(lineNo = 0; lineNo < lines.size() && nSpies_ == 0; lineNo++)
    {
        numbers = lines.at(lineNo).split(' ');
        nSpies_ = 0;
        for(int i = 0; i < numbers.size(); i++)
            if(numbers.at(i).toInt() > 0)
                nSpies_++;
    }
    if(nSpies_ != 0)
    {
        spies_ = new Spy*[nSpies_];
        actionsList_->setNKeyParts(nSpies_);
        for(lineNo--; lineNo < lines.size(); lineNo++)
        {
            numbers = lines.at(lineNo).split(' ');
            newKey = new int[nSpies_];
            keyPartNo = 0;
            for(int j = 0; j < numbers.size() && keyPartNo < nSpies_; j++)
            {
                if(numbers.at(j).toInt() > 0)
                    newKey[keyPartNo++] = numbers.at(j).toInt();
            }
            if(keyPartNo != nSpies_)
            {
                delete newKey;
            }
            else
            {
                currentPublicVariant = publicVariants_->begin();
                while(currentPublicVariant != publicVariants_->end())
                {
                    for(keyPartNo = 0; keyPartNo < nSpies_; keyPartNo++)
                    {
                        if(newKey[keyPartNo] != (*currentPublicVariant)[keyPartNo])
                            break;
                    }
                    if(keyPartNo == nSpies_)
                    {
                        delete newKey;
                        break;
                    }
                    currentPublicVariant++;
                }
                if(currentPublicVariant == publicVariants_->end())
                {
                    nVariants++;
                    publicVariants_->push_back(newKey);
                }
            }
        }
        for(int i = 0; i < nSpies_; i++)
        {
            newList = new QList<int *>(*publicVariants_);
            spies_[i] = new Spy(newList, i, publicVariants_->at(0)[i], nSpies_);
        }
        return nVariants;
    }
    else
        return 0;
}

MainWindow::~MainWindow()
{
    delete publicVariants_;
}
