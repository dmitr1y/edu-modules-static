#include <mainwindow.h>

#define N_TIPS 3

Info::Info(QWidget *parent)
    : QWidget(parent)
{
    QString problemFormulation, about;
    problemFormulation =
        QString("A number N of spies have a number N of\n")+
        QString("parts of the key, which is an ordered\n")+
        QString("set of numbers: spy №1 has the first\n")+
        QString("element of the set, spy №2 has the\n")+
        QString("second, etc. These spies can answer\n")+
        QString("questions like, \"Do you know the key?\"\n")+
        QString("or \"Does №k know the key? \", the\n")+
        QString("answer to which can only be \"yes\" or\n")+
        QString("\"no\".\n\n")+
        QString("Input of the program includes a set\n")+
        QString("of keys, among which is the desired\n")+
        QString("key. The program must ask questions\n")+
        QString("to spies (specifying the type of the\n")+
        QString("question and the spy who was asked)\n")+
        QString("to as long as one of the spies will\n")+
        QString("not be able to name the key.");

    about =
        QString("This application is developed by Ugarov\n")+
        QString("Anton as an alternative exam in discrete\n")+
        QString("mathematics. The program is developed\n")+
        QString("using Qt.\n\n")+
        QString("Email: deligor6321@gmail.com\n\n")+
        QString("2016 ETU \"LETI\"");

    QString *tipTexts = new QString[N_TIPS];
    tipTexts[0] =
        QString("First of all, You need to enter keys\n")+
        QString("into the right input box, one per\n")+
        QString("line. The key is to consist of the\n")+
        QString("natural numbers. Numbers less than\n")+
        QString("or equal to zero and the other\n")+
        QString("characters will be ignored. The keys\n")+
        QString("must be the same length. The extra\n")+
        QString("part will be ignored. You need to\n")+
        QString("enter a valid key in the first line.\n")+
        QString("An example of a correct entry can be\n")+
        QString("seen in the input box.");

    tipTexts[1] =
        QString("Then just click on the start button!\n")+
        QString("After that the program will compute\n")+
        QString("questions and answers and display them\n")+
        QString("in the left output box.");

    tipTexts[2] =
        QString("If you click on the fields with question\n")+
        QString("then you will be able to see the\n")+
        QString("consequences of response.\n");

    QPixmap *images = new QPixmap[N_TIPS];
    images[0].load(":/img/tip1.png");
    images[1].load(":/img/tip2.png");
    images[2].load(":/img/tip3.png");

    QLabel *aboutName = new QLabel("About");
    aboutName->setAlignment(Qt::AlignHCenter);
    aboutName->setMaximumHeight(30);
    aboutName->setStyleSheet("font-size: 20px;");
    about_ = new QLabel;
    about_->setText(about);

    QLabel *problemFormulationName = new QLabel("Formulation of the problem");
    problemFormulationName->setAlignment(Qt::AlignHCenter);
    problemFormulationName->setMaximumHeight(30);
    problemFormulationName->setStyleSheet("font-size: 20px");
    problemFormulation_ = new QLabel;
    problemFormulation_->setText(problemFormulation);

    QFrame *horizontalLine = new QFrame;
    horizontalLine->setFrameShape(QFrame::HLine);
    horizontalLine->setFrameShadow(QFrame::Sunken);

    leftLayout_ = new QVBoxLayout;
    leftLayout_->addWidget(problemFormulationName);
    leftLayout_->addWidget(problemFormulation_);
    leftLayout_->addWidget(horizontalLine);
    leftLayout_->addWidget(aboutName);
    leftLayout_->addWidget(about_);
    leftLayout_->setAlignment(Qt::AlignTop);

    QLabel *tipsName = new QLabel("Tips");
    tipsName->setAlignment(Qt::AlignHCenter);
    tipsName->setMaximumHeight(30);
    tipsName->setStyleSheet("font-size: 20px");
    tipsLayout_ = new QVBoxLayout;
    tipsLayout_->addWidget(tipsName);
    tips_ = new QHBoxLayout*[N_TIPS];
    tipLabels_ = new QLabel*[N_TIPS];
    tipImages_ = new QLabel*[N_TIPS];
    for(int i = 0; i < N_TIPS; i++)
    {
        tipLabels_[i] = new QLabel;
        tipLabels_[i]->setText(tipTexts[i]);
        tipLabels_[i]->setAlignment(Qt::AlignVCenter);

        tipImages_[i] = new QLabel;
        tipImages_[i]->setPixmap(images[i]);

        tips_[i] = new QHBoxLayout;
        if(i%2 == 0)
        {
            tips_[i]->addWidget(tipLabels_[i]);
            tips_[i]->addWidget(tipImages_[i]);
        }
        else
        {
            tips_[i]->addWidget(tipImages_[i]);
            tips_[i]->addWidget(tipLabels_[i]);
        }
        tipsLayout_->addLayout(tips_[i]);
    }

    QFrame* verticalLine = new QFrame;
    verticalLine->setFrameShape(QFrame::VLine);
    verticalLine->setFrameShadow(QFrame::Sunken);

    mainLayout_ = new QHBoxLayout;
    mainLayout_->addLayout(leftLayout_);
    mainLayout_->addWidget(verticalLine);
    mainLayout_->addLayout(tipsLayout_);

    setStyleSheet("background-color : white;");
    setLayout(mainLayout_);
    setWindowIcon(QIcon(":/img/logo.png"));
    setWindowTitle("Information");
    setMaximumHeight(300);
    setMaximumWidth(500);
}

Info::~Info()
{

}
