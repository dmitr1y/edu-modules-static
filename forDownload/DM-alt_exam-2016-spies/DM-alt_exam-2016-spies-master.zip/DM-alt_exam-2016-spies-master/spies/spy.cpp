#include "mainwindow.h"

Spy::Spy(QList<int *> *keyVariants, int spyNo, int keyPart, int nKeyParts)
{
    spyNo_ = spyNo;
    nKeyParts_ = nKeyParts;
    keyVariants_ = keyVariants;
    knownParts_ = new int[nKeyParts];
    answers_ = new bool[nKeyParts];
    for(int i = 0; i < nKeyParts; i++)
    {
        knownParts_[i] = 0;
        answers_[i] = 0;
    }
    knownParts_[spyNo] = keyPart;
}

bool Spy::getAnswer(int i)
{
    return answers_[i];
}

int Spy::computeConclusions(QList<int *> *publicVariants)
{
    int partNo, nParts;
    QList<int*>::iterator currentVariant, currentPublicVariant;

    currentVariant = keyVariants_->begin();
    while(currentVariant != keyVariants_->end())
    {
        currentPublicVariant = publicVariants->begin();
        while(currentPublicVariant != publicVariants->end())
        {
            if(*currentPublicVariant == *currentVariant)
                break;
            else
                currentPublicVariant++;
        }
        if(currentPublicVariant == publicVariants->end())
        {
            currentVariant = keyVariants_->erase(currentVariant);
        }
        else
            currentVariant++;
    }

    if(keyVariants_->empty())
        return 1;

    currentVariant = keyVariants_->begin();
    while(currentVariant != keyVariants_->end())
    {
        for(partNo = 0; partNo < nKeyParts_; partNo++)
        {
            if(knownParts_[partNo] != (*currentVariant)[partNo] && knownParts_[partNo] != 0)
            {
                currentVariant = keyVariants_->erase(currentVariant);
                break;
            }
        }
        if(partNo == nKeyParts_)
            currentVariant++;
    }

    if(keyVariants_->empty())
        return 1;
    if(keyVariants_->size() == 1)
            answers_[spyNo_] = 1;

    currentVariant = keyVariants_->begin();
    for(int partNo = 0; partNo < nKeyParts_; partNo++)
    {
        knownParts_[partNo] = (*currentVariant)[partNo];
    }
    currentVariant++;
    while(currentVariant != keyVariants_->end())
    {
        for(partNo = 0; partNo < nKeyParts_; partNo++)
            if(knownParts_[partNo] != (*currentVariant)[partNo])
                knownParts_[partNo] = 0;
        currentVariant++;
    }
    for(partNo = 0; partNo < nKeyParts_; partNo++)
        if(spyNo_ != partNo)
        {
            currentVariant = keyVariants_->begin();
            while(currentVariant != keyVariants_->end())
            {
                nParts = 0;
                currentPublicVariant = publicVariants->begin();
                while(currentPublicVariant != publicVariants->end())
                {
                    if((*currentVariant)[partNo] == (*currentPublicVariant)[partNo])
                        nParts++;
                    currentPublicVariant++;
                }
                if(nParts == 1)
                {
                    answers_[partNo] = 1;
                    break;
                }
                currentVariant++;
            }
        }
    return 0;
}

Spy::~Spy()
{
    delete answers_;
    delete knownParts_;
}
