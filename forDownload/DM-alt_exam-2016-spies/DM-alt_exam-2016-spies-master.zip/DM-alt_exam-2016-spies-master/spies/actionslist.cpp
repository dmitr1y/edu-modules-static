#include "mainwindow.h"

ActionsList::ActionsList(int nKeyParts, QWidget *parent)
    : QListWidget(parent)
{
    nKeyParts_ = nKeyParts;
}

void ActionsList::addQuestion(int from, int to, bool answer, QList<int *> *deletedVariants, QList<int *> *remainingVariants)
{
    QString line, text;
    QList<int *>::iterator currentVariant;

    QListWidgetItem *question = new QListWidgetItem;
    if(from != to)
    {
        text = "Number " + QString::number(from) +
                ", does number " + QString::number(to) +
                " know the key?\n" +
                (answer ? "yes" : "no");
    }
    else
    {
        text = "Number " + QString::number(from) +
                ", do you know the key?\n" +
                (answer ? "yes" : "no");
    }
    question->setText(text);
    question->setIcon(QIcon(":/img/arrow_right.png"));
    addItem(question);

    QListWidgetItem *info = new QListWidgetItem;
    text = "    Remaining variants of the key:\n";
    currentVariant = remainingVariants->begin();
    while(currentVariant != remainingVariants->end())
    {
        line = "    ";
        for(int i = 0; i < nKeyParts_; i++)
        {
            line += QString::number((*currentVariant)[i]) + " ";
        }
        line += "\n";
        text += line;
        currentVariant++;
    }
    if(deletedVariants != 0 && deletedVariants->size() != 0)
    {
        currentVariant = deletedVariants->begin();
        text += "\n    Deleted variants of the key:\n";
        while(currentVariant != deletedVariants->end())
        {
            line = "    ";
            for(int i = 0; i < nKeyParts_; i++)
            {
                line += QString::number((*currentVariant)[i]) + " ";
            }
            line += "\n";
            text += line;
            currentVariant++;
        }
    }
    else
    {
        text += "\n    There are no deleted variants of the key.\n";
    }
    info->setText(text);
    info->setFlags(Qt::NoItemFlags);
    info->setFlags(Qt::ItemIsEnabled);
    addItem(info);
    info->setHidden(true);
}

void ActionsList::addInput(QList<int *> *publicVariants)
{
    QString line, text;
    QList<int *>::iterator currentVariant;

    QListWidgetItem *input = new QListWidgetItem;
    text = "Input";
    input->setText(text);
    input->setIcon(QIcon(":/img/arrow_down.png"));
    addItem(input);

    QListWidgetItem *info = new QListWidgetItem;
    text = "    Input variants of the key:\n";
    currentVariant = publicVariants->begin();
    while(currentVariant != publicVariants->end())
    {
        line = "    ";
        for(int i = 0; i < nKeyParts_; i++)
        {
            line += QString::number((*currentVariant)[i]) + " ";
        }
        line += "\n";
        text += line;
        currentVariant++;
    }
    info->setText(text);
    info->setFlags(Qt::NoItemFlags);
    info->setFlags(Qt::ItemIsEnabled);
    addItem(info);
    info->setHidden(false);
}

void ActionsList::addFinal(QList<int *> *publicVariants)
{
    QString line, text;
    QList<int *>::iterator currentVariant;

    QListWidgetItem *final = new QListWidgetItem;
    if(publicVariants->size() == 1)
    {
        text = "The solution has been found!";
    }
    else
    {
        text = "There is no solution...";
    }
    final->setText(text);
    final->setIcon(QIcon(":/img/arrow_down.png"));
    addItem(final);

    QListWidgetItem *info = new QListWidgetItem;
    if(publicVariants->size() == 1)
    {
        text = "    The desired key: ";
    }
    else
    {
        text = "    Possible variants of the key:\n";
    }
    currentVariant = publicVariants->begin();
    while(currentVariant != publicVariants->end())
    {
        line = "    ";
        for(int i = 0; i < nKeyParts_; i++)
        {
            line += QString::number((*currentVariant)[i]) + " ";
        }
        line += "\n";
        text += line;
        currentVariant++;
    }
    info->setText(text);
    info->setFlags(Qt::NoItemFlags);
    info->setFlags(Qt::ItemIsEnabled);
    addItem(info);
    info->setHidden(false);
}


void ActionsList::hideInfo(QListWidgetItem *item)
{
    if(row(item)%2 == 0)
    {
        QListWidgetItem *info = this->item(row(item)+1);
        if(info->isHidden())
        {
            info->setHidden(false);
            item->setIcon(QIcon(":/img/arrow_down.png"));
        }
        else
        {
            info->setHidden(true);
            item->setIcon(QIcon(":/img/arrow_right.png"));
        }
    }
}


void ActionsList::setNKeyParts(int nKeyParts)
{
    nKeyParts_ = nKeyParts;
}

ActionsList::~ActionsList()
{
}

