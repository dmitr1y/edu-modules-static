﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using PokerDM.Utils;
using System.Threading.Tasks;

namespace PokerDM
{
    public class Game {

        Random rand = new Random();

        private static char[] suits = new char[] { 'D', 'H', 'S', 'C', 'a', 'b', '*'}; //Diamonds, Hearts, Spades, Clubs
        public static char[] Suits { get { return suits; } }

        private static char[] cards = new char[] { '2','3','4','5','6','7','8','9','T','J','Q','K','A'}; //Ten, Jack, Queen, King, Ace
        public static char[] Cards { get { return cards; } }

        public byte[,] Deck { get; set; }

        public PlayerCards playerCards;

        /// <summary>
        /// Возвращает количество карт выбранной масти
        /// </summary>
        /// <param name="suit">Масть</param>
        /// <returns></returns>
        public byte CountSuit(char suit) {
            byte result = 0;
            sbyte suitNumber = (sbyte)Array.IndexOf(Suits, suit);
            if (suitNumber==-1)
                throw new ArgumentOutOfRangeException();
            for (byte i = 0; i<13; i++)
                result+=Deck[i, suitNumber];
            return result;
        }

        /// <summary>
        /// Возвращает количество выбранных карт
        /// </summary>
        /// <param name="card">Карта</param>
        /// <returns></returns>
        public byte CountCard(char card) {
            byte result = 0;
            sbyte cardNumber = (sbyte)Array.IndexOf(Cards, card);
            if (cardNumber==-1)
                throw new ArgumentOutOfRangeException();
            for (byte i = 0; i<4; i++)
                result+=Deck[cardNumber, i];
            return result;
        }

        /// <summary>
        /// Возвращает выбранную карту
        /// </summary>
        /// <param name="card">Карта</param>
        /// <param name="suit">Масть</param>
        /// <returns></returns>
        public byte SelectedCard(char card, char suit) {
            return Deck[Array.IndexOf(Cards, card), Array.IndexOf(Suits, suit)];
        }

        /// <summary>
        /// Возвращает количество карт в колоде
        /// </summary>
        /// <returns></returns>
        public byte CountCards() {
            byte result = 0;
            foreach (var item in Deck) {
                result+=item;
            }
            return result;
        }

        /// <summary>
        /// Убирает выбранную карту из колоды
        /// </summary>
        /// <param name="card">Карта, которую нужно удалить</param>
        public void DeleteCard(Card card) {
            int[] buffer = new int[2] { Array.IndexOf(Cards, card.card.Item1), Array.IndexOf(Suits, card.card.Item2) };
            if (Deck[buffer[0], buffer[1]]<=0)
                throw new ArgumentException("Такой карты уже нет в колоде.");
            Deck[buffer[0], buffer[1]]-=1;
        }

        /// <summary>
        /// Генерирует рандомную карту из тех, что есть в колоде
        /// </summary>
        /// <returns></returns>
        public Card GenerateCard() {
            byte suit = 0;
            if (CountCards()<=0)
                throw new Exception("Карт больше нет.");
            do {
                suit=(byte)rand.Next(4);
            } while (CountSuit(Suits[suit])<=0);
            byte card = 0;
            do {
                card=(byte)rand.Next(13);
            } while (SelectedCard(Cards[card], Suits[suit])<=0);
            Card buffer = new Card(Cards[card], Suits[suit]);
            DeleteCard(buffer);
            return buffer;
        }

        public Card GenerateNotDoubleCard() {
            byte suit = 0;
            if (CountCards()<=0)
                throw new Exception("Карт больше нет.");
            do {
                suit=(byte)rand.Next(4);
            } while (CountSuit(Suits[suit])<=0);
            byte card = 0;
            do {
                card=(byte)rand.Next(13);
            } while ((CountCard(Cards[card])!=4));//(SelectedCard(Cards[card], Suits[suit])<=0)&&
            Card buffer = new Card(Cards[card], Suits[suit]);
            DeleteCard(buffer);
            return buffer;
        }

        /// <summary>
        /// Инициализирует полную колоду
        /// </summary>
        public Game():this(""){
            for (byte i = 0; i<5; i++)
                playerCards.Add(GenerateNotDoubleCard());
        }
        public Game(string _playerCads) {
            Deck=new byte[13, 4];
            for (int i = 0; i<13; i++)
                for (int j = 0; j<4; j++)
                    Deck[i, j]=1;
            playerCards=new PlayerCards(_playerCads);
            for (int i=0;i<playerCards.Cards.Count;i++){
                DeleteCard(playerCards.Cards[i]);
            }

        }
    }
}
