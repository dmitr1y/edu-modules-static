﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PokerDM.Utils {
    public static class StringCards {

        /// <summary>
        /// Возвращает сумму двух чисел в строке с плюсом
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public static int Count(string input) {
            return input.Split('+').Select(int.Parse).Sum();
        }

        /// <summary>
        /// Найти значение парметра и вернть его букву для подстановки
        /// </summary>
        /// <param name="input"></param>
        /// <param name="answer"></param>
        /// <param name="param"></param>
        /// <returns></returns>
        public static int FindParam(string input, int answer, out string param) {
            string[] buffer = input.Split('+');
            int result = answer-int.Parse(buffer[1]);
            param=buffer[0];
            return result;
        }

    }
}
