﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PokerDM.Utils {
    public class PlayerCards {
        private List<Card> cards;

        public List<Card> Cards { get { return cards; } set { cards=value; } }

        public override string ToString() {
            string result = "";
            foreach (Card card in Cards) {
                result+=card.ToString();
            }
            return result;
        }

        public void Add(Card card) {
            Cards.Add(card);
        }

        public bool SuitsEqual() {
            string suits = "";
            if (Cards.Count==0)
                return true;
            foreach (var card in Cards) {
                suits+=card.card.Item2;
            }
            return (suits.Replace(suits[0].ToString(), "")=="");
        }

        public void Drop(byte number) {
            Cards.RemoveAt(number-1);
        }

        /// <summary>
        /// Перемещает карту в руке на другую позицию
        /// </summary>
        public void ReSwap(byte lastPosition, byte newPosition) {
            Card buffer = cards[lastPosition];
            cards.Remove(buffer);
            cards.Insert(newPosition, buffer);
        }

        /// <summary>
        /// Меняет карту
        /// </summary>
        /// <param name="card">Карта для замены</param>
        /// <param name="position">Позиция для замены 1..5</param>
        /// <returns>Сброшенную карту</returns>
        public Card Swap(Card card, byte position) {
            Card result = Cards[position-1];
            Cards[position-1]=card;
            return result;
        }

        /// <summary>
        /// Возвращает карты из первого набора, которых нет во 2
        /// </summary>
        /// <param name="a"></param>
        /// <param name="b"></param>
        /// <returns></returns>
        public static PlayerCards operator-(PlayerCards a, PlayerCards b) {
            PlayerCards result = new PlayerCards();
            foreach (Card card in a.Cards) {
                if (!b.Cards.Contains<Card>(card))
                    result.Add(card);
            }
            return result;
        }

        public PlayerCards() {
            Cards=new List<Card>();
        }

        public PlayerCards(string _cards):this() {
            if (_cards.Length%6!=0)
                throw new ArgumentException("Неверная строка");
            while (_cards.Length>0) {
                Add(new Card(_cards[1], _cards[4]));
                _cards=_cards.Remove(0, 6);
            }
        }
    }
}
