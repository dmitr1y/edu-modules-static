﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;
using System.Threading.Tasks;

namespace PokerDM.Utils {
    public class Statistic {
        /// <summary>
        /// Формула размещений
        /// </summary>
        /// <param name="n">Количество объектов</param>
        /// <param name="m">Выбираемые объекты</param>
        /// <returns></returns>
        public static bRat A(int n, int m) {
            if (n<m)
                return new bRat(0, 1);
            return (new Factorial(n)/new Factorial(n-m)).Count();
        }

        /// <summary>
        /// Формулы сочетания
        /// </summary>
        /// <param name="n">Количество различных объектов</param>
        /// <param name="m">Количество выбранных объектов</param>
        /// <returns>C</returns>
        public static BigInteger C(int n, int m) {
            if (n<m)
                return 0;
            return (new Factorial(n)/(new Factorial(n-m)*new Factorial(m))).Count();
        }

    }
}