﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.IO;
using System.Threading.Tasks;

namespace PokerDM.Utils {
    public class Combinations {

        static SortedList<string, BigInteger> mem;

        public static BigInteger Combination(Game game, PlayerCards cards, string combination) {
            if (combination=="Royal Flush")
                mem=new SortedList<string, BigInteger>();
            StreamReader sr = new StreamReader("../../../PokerDM/Combinations/"+combination);
            string buffer = "";
            PlayerCards comb;
            BigInteger result = 0;
            while (sr.Peek()>=0) {
                buffer=sr.ReadLine();
                comb=new PlayerCards(buffer);
                if (comb.Cards.Count<5) {
                    if ((cards-comb).Cards.Count>(5-comb.Cards.Count))
                        continue;
                    comb-=cards;
                    if (comb.ToString()=="") {
                        
                        result+=Statistic.C(game.CountCards(), 5-cards.Cards.Count);//########################################################################
                        break;
                    } else {
                        BigInteger buffer2 = 1;
                        for (byte i = 0; i<comb.Cards.Count; i++) {
                            buffer2*=game.SelectedCard(comb.Cards[i].card.Item1, comb.Cards[i].card.Item2);
                        }
                        buffer2*=Statistic.C(game.CountCards()-comb.Cards.Count, 5-cards.Cards.Count-comb.Cards.Count);//#####################################
                        result+=buffer2;
                    }
                } else {
                    if (cards.Cards.Count==5&&(cards-comb).ToString()=="") {
                        result++;
                        continue;
                    } else if ((cards-comb).ToString()!="") {
                        continue;
                    } else if ((cards-comb).ToString()=="") {
                        comb-=cards;
                        BigInteger buf = 0;
                        foreach (Card item in comb.Cards) {
                            if (game.SelectedCard(item.card.Item1, item.card.Item2)!=0)
                                buf++;
                            else
                                break;
                        }
                        if (buf==comb.Cards.Count)
                            result++;
                    }
                }
            }
            sr.Close();

            if (combination=="Two Pairs"||combination=="Three of a kind"||combination=="Pair") {
                if (cards.Cards.Count==0)
                    result-=mem["Flush"];
                else if (cards.SuitsEqual())
                    result-=Statistic.C(game.CountSuit(cards.Cards[0].card.Item2), 5-cards.Cards.Count);
            }
            if (combination=="Two Pairs")
                result-=(mem["Full House"]+mem["Three of a kind"]);
            else if (combination=="Three of a kind")
                result-=(mem["Four of a kind"]+mem["Full House"]);
            else if (combination=="Pair")
                result-=(mem["Four of a kind"]+mem["Full House"]+mem["Three of a kind"]+mem["Two Pairs"]);
            mem.Add(combination, result);
            return result;
        }

    }
}
