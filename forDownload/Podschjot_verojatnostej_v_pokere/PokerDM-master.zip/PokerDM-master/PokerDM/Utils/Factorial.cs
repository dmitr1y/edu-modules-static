﻿using System;
using System.Numerics;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PokerDM.Utils {

    public class Factorial {

        /// <summary>
        /// Массив простых чисел до 401 (c ОГРОМНЫМ ЗАПАСОМ)
        /// </summary>
        public static short[] simple = new short[] { 2, 3, 5, 7, 11, 13, 17, 19, 23,
            29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101,
            103, 107, 109, 113, 127, 131, 137, 139, 149, 151, 157, 163, 167, 173,
            179, 181, 191, 193, 197, 199, 211, 223, 227, 229, 233, 239, 241, 251,
            257, 263, 269, 271, 277, 281, 283, 293, 307, 311, 313, 317, 331, 337,
            347, 349, 353, 359, 367, 373, 379, 383, 389, 397, 401 };

        /// <summary>
        /// Список простых чисел со степенями
        /// </summary>
        public SortedList<int, int> pows = new SortedList<int, int>();

        /// <summary>
        /// Вычисляет степени простых чисел для факториала
        /// </summary>
        /// <param name="n">Факториал</param>
        public Factorial(int n) {
            if (n<0) {
                pows.Add(0,1);
            }else if (n==0) {
                pows.Add(1,1);
            } else if (n==1||n==2) {
                pows.Add(n,1);
            } else {
                int k=0;
                int c = 0;
                foreach (short sim in simple) {
                    k=n/sim;
                    c=0;
                    while (k>0) {
                        c+=k;
                        k/=sim;
                    }
                    if (c!=0)
                        pows.Add(sim, c);
                    else
                        break;
                }
            }
        }

        /// <summary>
        /// Создаёт факториал из списка степеней
        /// </summary>
        /// <param name="input"></param>
        public Factorial(SortedList<int, int> input) {
            pows=input;
        }

        /// <summary>
        /// Возводит число в степень n
        /// </summary>
        /// <param name="input">Число</param>
        /// <param name="n">Степень</param>
        /// <returns>a^n</returns>
        public static BigInteger Pow(BigInteger input, int n) {
            BigInteger a = input;
            if (n==0)
                return 1;
            n--;
            while (n>0) {
                if ((n&1)==1)
                    input*=a;
                a*=a;
                n>>=1;
            }
            return input;
        }

        /// <summary>
        /// Возвращает факториал из степеней
        /// </summary>
        /// <returns>Факториал числа</returns>
        public BigInteger Count() {
            BigInteger buffer = new BigInteger(1);
            foreach (var item in pows) {
                buffer*=Pow(item.Key, item.Value);
            }
            return buffer;
        }

        /// <summary>
        /// Деление факториалов (чтобы я мог не пересчитывать все и просто с ними работать)
        /// </summary>
        /// <returns>Частное от деления</returns>
        public static Factorial operator /(Factorial a, Factorial b) {
            for (int i =0;i<a.pows.Keys.Count;i++) {//Перебираем все степени из числителя и сокращаем их
                int key = a.pows.Keys[i];
                if (b.pows.ContainsKey(key)) {//Если в знаменателе есть такое основание
                    int sec = b.pows[key];//Степень основания в знаменателе
                    if (sec<=a.pows[key]) {//Если степень знаменателя меньше или равна
                        a.pows[key]-=sec;
                        b.pows[key]=0;
                    }
                    else {//Если в знаменателе больше
                        b.pows[key]-=a.pows[key];
                        a.pows[key]=0;
                    }
                }
            }
            return a;

        }

        /// <summary>
        /// Умножает два факториала
        /// </summary>
        /// <param name="a">Первый факториал</param>
        /// <param name="b">Второй факториал</param>
        /// <returns></returns>
        public static Factorial operator *(Factorial a, Factorial b) {
            foreach (var item in b.pows) {
                if (a.pows.ContainsKey(item.Key)) {
                    a.pows[item.Key]+=item.Value;
                }
                else {
                    a.pows.Add(item.Key, item.Value);
                }
            }
            return new Factorial(a.pows);
        }
    }
}
