﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PokerDM.Utils {
    public class Card:IComparable, IEquatable<Card> {
        /// <summary>
        /// Карта, Масть
        /// </summary>
        public Tuple<char, char> card { get; set; }

        public bool Equals(Card other) {
            if (card.Item1==other.card.Item1&&card.Item2==other.card.Item2)
                return true;
            return false;
        }

        /// <summary>
        /// Возвращает строку
        /// </summary>
        /// <returns></returns>
        public override string ToString() {
            return card.ToString();
        }

        public int CompareTo(object another) {
            Card _card = another as Card;
            if (_card==null)
                throw new ArgumentException("Это не карта.");
            int delete = Array.IndexOf(Game.Cards, card.Item1).CompareTo(Array.IndexOf(Game.Cards, _card.card.Item1));
            return delete;
        }

        public Card(char _card, char _suit) {
            if (Array.IndexOf(Game.Cards, _card)==-1||Array.IndexOf(Game.Suits, _suit)==-1)
                throw new ArgumentException("Нет такой карты.");
            card=new Tuple<char, char>(_card, _suit);            
        }
    }
}
