﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using PokerDM;
using PokerDM.Utils;

namespace TestPokerDM {
    class Program {
        static string[] combinations = new string[] { "Royal Flush", "Straight Flush", "Four of a kind", "Full House", "Flush", "Straight", "Three of a kind", "Two Pairs"};

        static void Main(string[] args) {
            string input = "";
            const int N = 5;
            Console.Title="Poker Helper v0.9";
            while (input!="e") {
                // 2 3 4 5 6 7 8 9 T J Q K A //карты
                // D H S C // масти
                Game game = new Game();
                //Console.WriteLine("Выберите режим: (1 - авто, 2 - ручной)");
                Console.ForegroundColor=ConsoleColor.Gray;
                //try{
                //int menu=int.Parse(Console.ReadLine());
                //    if (menu==1)
                //        game=new Game();
                //    else if (menu==2)
                //        game=new Game("(2, C)(3, D)(A, S)(3, C)(4, D)");//Console.ReadLine());
                //    else
                //        break;
                //} catch (Exception) { break; }
                Console.WriteLine("Ваши карты: "+((game.playerCards.ToString()=="") ? "У вас нет карт" : game.playerCards.ToString()));
                Console.ForegroundColor=ConsoleColor.Yellow;
                Console.WriteLine("Выберите карты для сброса (1..5)\r\nНапример: '1 3 4' сбросит первую, третью и четвёртую карты.");
                Console.ForegroundColor=ConsoleColor.Gray;
                input=Console.ReadLine();
                byte minus = 0;
                if (input!="")
                try {
                    foreach (byte item in input.Split(' ').Select(byte.Parse).ToArray())
                        game.playerCards.Drop((byte)(item-minus++));
                } catch (Exception) { break; }
                Console.WriteLine("Ваши карты после сброса: "+((game.playerCards.ToString()=="")?"У вас нет карт": game.playerCards.ToString()));
                foreach (string comb in combinations) {
                    BigInteger result = Combinations.Combination(game, game.playerCards, comb);
                    BigInteger all = Statistic.C(game.CountCards(), 5-game.playerCards.Cards.Count);
                    bRat res = new bRat(result*100, all);
                    string part="";
                    bRat lol = res.GetFractionPart();
                    bool tilda = false;
                    if (res.GetFractionPart() != new bRat(0, res.Denominator)) {
                        part = ((res.GetFractionPart() * BigInteger.Parse("1" + new string('0', N))).GetWholePart()*res.Sign).ToString();
                        part = "."+(new string('0', N - part.Length)) + part;
                        tilda=true;
                    }
                    BigInteger percents = res.GetWholePart();
                    if (result!=0)
                        Console.ForegroundColor=ConsoleColor.Green;
                    else
                        Console.ForegroundColor=ConsoleColor.DarkGreen;
                    Console.WriteLine("{0}: "+((tilda)?"~":"")+"{3:D}{4}%", (comb+new string(' ', 15-comb.Length)), string.Format(result.ToString(),"#####"), all, percents, part);
                }
                Console.ForegroundColor=ConsoleColor.Gray;
                Console.WriteLine("Готово!");
                input="e";
                Console.ReadKey();
            }
        }
    }
}
