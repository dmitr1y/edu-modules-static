﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using PokerDM.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PokerDM.Utils.Tests {
    [TestClass()]
    public class PlayerCardsTests {
        [TestMethod()]
        public void ToString_Test() {
            PlayerCards pc = new PlayerCards();
            pc.Add(new Card('T', 'D'));
            pc.Add(new Card('3', 'S'));
            Assert.AreEqual("(3, S)", pc.Swap(new Card('Q', 'C'), 2).ToString());
            Assert.AreEqual("(T, D)(Q, C)", pc.ToString());
        }

        [TestMethod()]
        public void Sort_Test() {
            PlayerCards pc = new PlayerCards();
            pc.Add(new Card('A', 'C'));
            pc.Add(new Card('3', 'S'));
            pc.Add(new Card('T', 'D'));
            pc.Add(new Card('2', 'C'));
            pc.Add(new Card('2', 'D'));
            pc.Add(new Card('6', 'C'));
            pc.Add(new Card('8', 'H'));
            pc.Add(new Card('Q', 'S'));
            pc.Cards.Sort();
            Assert.AreEqual("(2, C)(2, D)(3, S)(6, C)(8, H)(T, D)(Q, S)(A, C)", pc.ToString());
        }

        [TestMethod()]
        public void ReSwap_Test() {
            PlayerCards pc = new PlayerCards();
            pc.Add(new Card('A', 'C'));
            pc.Add(new Card('3', 'S'));
            pc.Add(new Card('T', 'D'));
            pc.Add(new Card('2', 'C'));
            pc.Add(new Card('2', 'D'));
            pc.Add(new Card('6', 'C'));
            pc.Add(new Card('8', 'H'));
            pc.Add(new Card('Q', 'S'));
            pc.Cards.Sort();
            //_________________1_____2_____3_____4_____5_____6_____7_____8
            Assert.AreEqual("(2, C)(2, D)(3, S)(6, C)(8, H)(T, D)(Q, S)(A, C)", pc.ToString());
            pc.ReSwap(4, 1);
            Assert.AreEqual("(2, C)(8, H)(2, D)(3, S)(6, C)(T, D)(Q, S)(A, C)", pc.ToString());
            pc.ReSwap(0, 3);
            Assert.AreEqual("(8, H)(2, D)(3, S)(2, C)(6, C)(T, D)(Q, S)(A, C)", pc.ToString());
            pc.ReSwap(5, 2);
            Assert.AreEqual("(8, H)(2, D)(T, D)(3, S)(2, C)(6, C)(Q, S)(A, C)", pc.ToString());
            pc.ReSwap(2, 5);
            Assert.AreEqual("(8, H)(2, D)(3, S)(2, C)(6, C)(T, D)(Q, S)(A, C)", pc.ToString());
        }

        [TestMethod()]
        public void Minus_Test() {
            PlayerCards one = new PlayerCards();
            one.Add(new Card('A', 'C'));
            one.Add(new Card('3', 'S'));
            one.Add(new Card('T', 'D'));
            one.Add(new Card('2', 'C'));
            one.Add(new Card('2', 'D'));
            one.Add(new Card('6', 'C'));
            one.Add(new Card('8', 'H'));
            one.Add(new Card('Q', 'S'));
            PlayerCards two = new PlayerCards();
            two.Add(new Card('A', 'C'));
            two.Add(new Card('3', 'S'));
            two.Add(new Card('T', 'D'));
            two.Add(new Card('2', 'C'));
            two.Add(new Card('2', 'D'));
            two.Add(new Card('6', 'C'));
            two.Add(new Card('8', 'H'));
            two.Add(new Card('Q', 'S'));

            Assert.AreEqual("", (one-two).ToString());
            one.Swap(new Card('5', 'S'), 3);
            Assert.AreEqual("(5, S)", (one-two).ToString());
            Assert.AreEqual("(T, D)", (two-one).ToString());
        }

        [TestMethod()]
        public void PlayerCards_Test() {
            PlayerCards pc = new PlayerCards("(2, C)(2, D)(3, S)(6, C)(8, H)(T, D)(Q, S)(A, C)");
            Assert.AreEqual("(2, C)(2, D)(3, S)(6, C)(8, H)(T, D)(Q, S)(A, C)", pc.ToString());
        }

        [TestMethod()]
        public void SuitsEqual_Test() {
            PlayerCards one = new PlayerCards();
            one.Add(new Card('A', 'C'));
            one.Add(new Card('3', 'C'));
            one.Add(new Card('T', 'S'));
            one.Add(new Card('2', 'C'));
            one.Add(new Card('2', 'C'));
            one.Add(new Card('6', 'C'));
            one.Add(new Card('8', 'C'));
            one.Add(new Card('Q', 'C'));
            Assert.AreEqual("False", one.SuitsEqual().ToString());
            PlayerCards two = new PlayerCards();
            Assert.AreEqual("True", two.SuitsEqual().ToString());
            PlayerCards three = new PlayerCards();
            three.Add(new Card('Q', 'C'));
            three.Add(new Card('T', 'C'));
            three.Add(new Card('5', 'C'));
            three.Add(new Card('K', 'C'));
            three.Add(new Card('3', 'C'));
            Assert.AreEqual("True", three.SuitsEqual().ToString());
        }
    }
}