﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using PokerDM.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PokerDM.Utils.Tests {
    [TestClass()]
    public class FactorialTests {
        [TestMethod()]
        public void Factorial_Test() {
            Factorial f = new Factorial(30);
            Assert.AreEqual("265252859812191058636308480000000", f.Count().ToString());
        }
    }
}