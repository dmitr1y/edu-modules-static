﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using PokerDM.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PokerDM.Utils.Tests {
    [TestClass()]
    public class StringCardsTests {
        [TestMethod()]
        public void Count_Test() {
            Assert.AreEqual(12, StringCards.Count("10+2"));
            Assert.AreEqual(3, StringCards.Count("0+3"));
            Assert.AreEqual(9, StringCards.Count("8+1"));
        }

        [TestMethod()]
        public void FindParam_Test() {
            string buffer = "";
            int answer = 0;
            for (int i=1; i<5; i++) {
                answer=StringCards.FindParam(((i<3)?"n+":"x+")+(13-i).ToString(),13, out buffer);
                Assert.AreEqual(i, answer);
                Assert.AreEqual((i<3)?"n":"x",buffer);
            }
        }
    }
}