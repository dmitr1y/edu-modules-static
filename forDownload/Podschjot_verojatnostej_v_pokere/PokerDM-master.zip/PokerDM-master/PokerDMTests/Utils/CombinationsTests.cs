﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using PokerDM.Utils;
using System.Numerics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PokerDM.Utils.Tests {
    [TestClass()]
    public class CombinationsTests {
        [TestMethod()]
        public void Combination_Test() {
            Game game = new Game("");
            //Для теста нужно зкоментить удаление карт при генерации
            //Royal Flush
            Assert.AreEqual(1, Combinations.Combination(game, new PlayerCards("(T, D)(J, D)(Q, D)(K, D)(A, D)"), "Royal Flush"));
            Assert.AreEqual(0, Combinations.Combination(game, new PlayerCards("(T, C)(J, C)(Q, C)(K, C)(3, C)"), "Royal Flush"));
            Assert.AreEqual(1, Combinations.Combination(game, new PlayerCards("(T, H)(J, H)(Q, H)(K, H)"), "Royal Flush"));
            Assert.AreEqual(1, Combinations.Combination(game, new PlayerCards("(T, S)(J, S)(Q, S)(K, S)(A, S)"), "Royal Flush"));
            Assert.AreEqual(1, Combinations.Combination(game, new PlayerCards("(T, C)(J, C)(Q, C)(K, C)(A, C)"), "Royal Flush"));
            Assert.AreEqual(1, Combinations.Combination(game, new PlayerCards("(A, C)(Q, C)(J, C)(K, C)(T, C)"), "Royal Flush"));
            Assert.AreEqual(4, Combinations.Combination(game, new PlayerCards(""), "Royal Flush"));
            Assert.AreEqual(0, Combinations.Combination(game, new PlayerCards("(Q, C)(7, C)(K, C)(T, C)"), "Royal Flush"));
            //Straight Flush
            Assert.AreEqual(0, Combinations.Combination(game, new PlayerCards("(T, S)(J, S)(Q, S)(K, S)(A, S)"), "Straight Flush"));
            Assert.AreEqual(1, Combinations.Combination(game, new PlayerCards("(3, C)(5, C)(4, C)(2, C)(6, C)"), "Straight Flush"));
            Assert.AreEqual(2, Combinations.Combination(game, new PlayerCards("(3, C)(5, C)(4, C)(6, C)"), "Straight Flush"));
            Assert.AreEqual(3, Combinations.Combination(game, new PlayerCards("(5, C)(4, C)(6, C)"), "Straight Flush"));
            Assert.AreEqual(36, Combinations.Combination(game, new PlayerCards(""), "Straight Flush"));
        }
    }
}