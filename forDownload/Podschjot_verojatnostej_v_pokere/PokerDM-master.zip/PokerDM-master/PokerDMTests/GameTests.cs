﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using PokerDM;
using PokerDM.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PokerDM.Tests {
    [TestClass()]
    public class GameTests {

        [TestMethod()]
        public void CountSuit_Test() {
            Game game = new Game("");
            Assert.AreEqual(13, game.CountSuit('C'));
        }

        [TestMethod()]
        public void CountCard_Test() {
            Game game = new Game("");
            Assert.AreEqual(4, game.CountCard('T'));
        }

        [TestMethod()]
        public void Card_Test() {
            Game game = new Game("");
            Assert.AreEqual(1, game.SelectedCard('T', 'D'));
        }

        [TestMethod()]
        public void CountCards_Test() {
            Game game = new Game("");
            Assert.AreEqual(52, game.CountCards());
        }

        [TestMethod()]
        public void GenerateCard_Test() {
            Game game = new Game("");
            List<string> cards = new List<string>();
            for (int i=0;i<47;i++)
                cards.Add(game.GenerateCard().ToString());
            CollectionAssert.AllItemsAreUnique(cards);
        }
    }
}