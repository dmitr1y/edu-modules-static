#ifndef SUDOKU_H
#define SUDOKU_H


class Sudoku
{
public:
    Sudoku();
};

#endif // SUDOKU_H