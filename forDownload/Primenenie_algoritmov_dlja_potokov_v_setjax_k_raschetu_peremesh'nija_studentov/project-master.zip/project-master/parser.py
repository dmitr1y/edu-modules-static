def sort_time(day):
    n = 1
    while n < len(day):
        for i in range(len(day) - n):
            if day[i][0] == day[i + 1][0] and int(day[i][1].split('.')[0]) > int(day[i + 1][1].split('.')[0]):
                day[i], day[i + 1] = day[i + 1], day[i]
        n += 1


def check_time(first, two):
    if (first == "8.00" and two == "9.50") \
            or (first == "9.50" and two == "11.40") \
            or (first == "11.40" and two == "13.45") \
            or (first == "13.45" and two == "15.35") \
            or (first == "15.35" and two == "17.25"):
        return True
    else:
        return False


def fucn_day(row_index):
    col_index = 0
    value = str(sheet.cell(row_index, col_index).value)
    while not value:
        row_index -= 1
        value = str(sheet.cell(row_index, col_index).value)
    return value


def fucn_time(row_index):
    col_index = 1
    value = sheet.cell(row_index, col_index).value
    while not value:
        row_index -= 1
        value = sheet.cell(row_index, col_index).value
    if float(value) < 1:
        value = xldate_as_tuple(value, 1)
        time = str(value[3]) + "." + str(value[4])
    else:
        time = value
    return time


from xlrd import open_workbook, xldate_as_tuple
from re import findall, search

wb = open_workbook('test.xls')
sheet = wb.sheet_by_index(0)

pattern_one = r'.*([35]{1}\d{3})'
pattern_two = r'.*(У[Ии]Т)'

days = [[] for i in range(6)]

for col_index in range(2, sheet.ncols):
    if sheet.cell(0, col_index).value:
        for row_index in range(1, sheet.nrows):
            value = str(sheet.cell(row_index, col_index).value)
            if value:
                if search(pattern_two, value):
                    value = findall(pattern_two, value)
                else:
                    if value == "пр.":
                        value = findall(pattern_one, str(sheet.cell(row_index, col_index + 1).value))
                    else:
                        value = findall(pattern_one, value)
                if value:
                    value = value[0]
                    if fucn_day(row_index) == "ПОНЕДЕЛЬНИК":
                        days[0].append(
                            (int(sheet.cell(0, col_index).value), fucn_time(row_index), value, "ПОНЕДЕЛЬНИК"))
                    elif fucn_day(row_index) == "ВТОРНИК":
                        days[1].append((int(sheet.cell(0, col_index).value), fucn_time(row_index), value, "ВТОРНИК"))
                    elif fucn_day(row_index) == "СРЕДА":
                        days[2].append((int(sheet.cell(0, col_index).value), fucn_time(row_index), value, "СРЕДА"))
                    elif fucn_day(row_index) == "ЧЕТВЕРГ":
                        days[3].append((int(sheet.cell(0, col_index).value), fucn_time(row_index), value, "ЧЕТВЕРГ"))
                    elif fucn_day(row_index) == "ПЯТНИЦА":
                        days[4].append((int(sheet.cell(0, col_index).value), fucn_time(row_index), value, "ПЯТНИЦА"))
                    elif fucn_day(row_index) == "СУББОТА":
                        days[5].append((int(sheet.cell(0, col_index).value), fucn_time(row_index), value, "СУББОТА"))

days = [list(set(days[i])) for i in range(6)]
for j in range(len(days)):
    days[j].sort()
    sort_time(days[j])
    for i in range(1, len(days[j])):
        if days[j][i][0] == days[j][i - 1][0] and check_time(days[j][i - 1][1], days[j][i][1]):
            print(days[j][i][3], days[j][i][0], days[j][i][1], days[j][i - 1][2], days[j][i][2])
            # with open("Расписание/" + days[j][i][3] + '/' + days[j][i][1] + '.txt','a') as file:
            #     print(days[j][i][0], days[j][i][1], days[j][i - 1][2] ,days[j][i][2], file=file)
