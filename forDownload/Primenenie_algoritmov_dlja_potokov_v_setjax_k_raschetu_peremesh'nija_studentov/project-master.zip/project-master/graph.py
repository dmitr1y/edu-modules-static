import math

import networkx as nx
days = ["ПОНЕДЕЛЬНИК", "ВТОРНИК", "СРЕДА", "ЧЕТВЕРГ", "ПЯТНИЦА", "СУББОТА"]
days_time = ["11.25", "13.30", "15.20", "17.10"]


class Time():
    def __init__(self):
        self.minute = 0
        self.second = 0
        self.hour = 0

    def add(self, number):
        self.second += number
        self.minute += self.second // 60
        self.second = self.second % 60
        self.hour += self.minute // 60
        self.minute = self.minute % 60

    def string(self):
        if self.second > 9:
            return str(self.hour) + ":" + str(self.minute) + ":" + str(self.second)
        else:
            return str(self.hour) + ":" + str(self.minute) + ":0" + str(self.second)

class Graph():

    def __init__(self, a, b):
        self.list_node = None
        self.schedule = None
        self.day = a
        self.day_time = b


    def read_nodes_graph(self, name):
        array = []
        with open(name, 'r') as f:
            for line in f.readlines():
                a = line.upper().split()
                a[2] = int(a[2])
                a = tuple(a)
                array.append(a)
        return array

    def read_schedule(self):

        directory = "Расписание/" + self.day + "/" + self.day_time + ".txt"
        schedule = []
        try:
            with open(directory, 'r') as file:
                for line in file.readlines():
                    line = line.strip().split()
                    if line[2] != line[3]:
                        schedule.append([line[2], line[3], line[0]])
        except FileNotFoundError:
            pass
        return schedule


    def analysis_graph(self):
        graph = nx.Graph()
        for array in self.list_node:
            if array[0][0] == '3':
                d = 3
            elif array[0][0] == '5':
                d = 2
            elif array[0][0] == 'Л' and array[0][1]=='3':
                d = 2
            elif 'М' in array[0]:
                d = 3
            else:
                d = 1
            try:
                graph.add_edge(array[0], array[1], weight=array[2], capacity=math.ceil(60 / (24 // d + array[2])))
            except ZeroDivisionError:
                graph.add_edge(array[0], array[1], weight=array[2], capacity=1000)

        time = Time()

        dictonary = {}

        for move in self.schedule:
            try:
                path = nx.dijkstra_path(graph, move[0], move[1])
                time.hour = int(self.day_time.split('.')[0])
                time.minute = int(self.day_time.split('.')[1])
                time.second = 0
                for j in range(1, len(path)):
                    weight = (graph.edge[path[j - 1]][path[j]]['weight'])
                    capacity = (graph.edge[path[j - 1]][path[j]]['capacity'])
                    time.add(weight)
                    string = time.string() + " " + path[j] + '/' + path[j-1]

                    if string in dictonary.keys():
                        dictonary[string] += 1/capacity
                    else:
                        dictonary[string] = 1/capacity
            except nx.exception.NetworkXNoPath:
                print(move)
            except KeyError:
                print(move)

        finall = []
        for key, value in dictonary.items():
            if value > 2:
                finall.append(str(int(value)) + ' - ' + str(key))
        finall.sort(key=lambda x: int(x.split(' - ')[0]), reverse=True)
        return finall

    def optimization_graph(self):
        main_graph = nx.Graph()
        main_graph.add_weighted_edges_from(self.list_node)
        graph = nx.Graph()
        flow_net = nx.Graph()
        for array in self.list_node:
            if array[0][0] == '3':
                d = 3
            elif array[0][0] == '5':
                d = 2
            elif array[0][0] == 'Л' and array[0][1] == '3':
                d = 2
            elif 'М' in array[0]:
                d = 3
            elif array[0][0] == 'Л' and array[0][1] == '5':
                d = 1
            else:
                d = 1
            try:
                flow_net.add_edge(array[0], array[1], weight=array[2])
                graph.add_edge(array[0], array[1], weight=0, capacity=math.ceil(60 / (24 // d + array[2])))
            except ZeroDivisionError:
                flow_net.add_edge(array[0], array[1], weight=array[2])
                graph.add_edge(array[0], array[1], weight=0, capacity=1000)

        opt_paths = [[] for move in self.schedule]
        prev_node = []
        cur_node = []
        j = 0
        for move in self.schedule:
            try:
                path = nx.dijkstra_path(flow_net, move[0], move[1])
                opt_paths[j].append(path[0]);
                prev_node.append(path[0])
                cur_node.append(path[1])
                graph.edge[path[0]][path[1]]['weight'] += 1
                if graph.edge[path[0]][path[1]]['capacity'] - graph.edge[path[0]][path[1]]['weight'] <= 0:
                    flow_net.remove_edge(path[0], path[1])
            except KeyError:
                pass
            except nx.exception.NetworkXNoPath:
                prev_node.append(path[0])
                cur_node.append(path[0])
                pass
            j += 1

        for i in range(1, 27):
            j = 0
            for move in self.schedule:
                try:
                    if(cur_node[j] != move[1]):
                        path = nx.dijkstra_path(flow_net, cur_node[j], move[1])
                        graph.edge[cur_node[j]][path[1]]['weight'] += 1
                        graph.edge[cur_node[j]][prev_node[j]]['weight'] -= 1
                        opt_paths[j].append(cur_node[j])
                        if graph.edge[cur_node[j]][path[1]]['capacity'] - graph.edge[cur_node[j]][path[1]]['weight'] <= 0:
                            flow_net.remove_edge(cur_node[j], path[1])
                        if graph.edge[cur_node[j]][prev_node[j]]['capacity'] - graph.edge[cur_node[j]][prev_node[j]]['weight'] > 0:
                            if flow_net.has_edge(prev_node[j], cur_node[j]) == False:
                              flow_net.add_edge(prev_node[j], cur_node[j], weight=main_graph.edge[prev_node[j]][cur_node[j]]['weight'])
                        prev_node[j] = cur_node[j]
                        cur_node[j] = path[1]

                    else:
                        if move[1] not in opt_paths[j]:
                            opt_paths[j].append(move[1])
                            graph.edge[prev_node[j]][cur_node[j]]['weight'] -= 1

                except KeyError:
                    print('err4')
                except nx.exception.NetworkXNoPath:
                    print('err5')
                j += 1


        j = 0
        time_1 = Time()

        time_1.hour = int(self.day_time.split('.')[0])
        time_1.minute = int(self.day_time.split('.')[1])
        time_1.second = 0

        with open('optimazed_path.txt', 'w') as file:
            for move in self.schedule:
                try:
                    path = nx.dijkstra_path(graph, move[0], move[1])
                    print(move[2], time_1.string()[:5], file=file)
                    print("Старый путь: ", '->'.join(opt_paths[j]), file=file)
                    print("Новый путь: ", '->'.join(path), file=file, end='\n\n')
                except KeyError:
                    pass
                except nx.exception.NetworkXNoPath:
                    pass
                j += 1

        time = Time()

        dictonary = {}
        for path in opt_paths:
            try:

                time.hour = int(self.day_time.split('.')[0])
                time.minute = int(self.day_time.split('.')[1])
                time.second = 0

                for j in range(1, len(path)):
                    weight = (main_graph.edge[path[j - 1]][path[j]]['weight'])
                    capacity = (graph.edge[path[j - 1]][path[j]]['capacity'])
                    time.add(weight)
                    string = time.string() + " " + path[j] + '/' + path[j-1]
                    if string in dictonary.keys():
                        dictonary[string] += 1 / capacity
                    else:
                        dictonary[string] = 1 / capacity
            except nx.exception.NetworkXNoPath:
                pass
            except KeyError:
                pass

        finall = []
        for key, value in dictonary.items():
            if value > 2:
                finall.append(str(int(value)) + ' - ' + str(key))
        finall.sort(key=lambda x: int(x.split(' - ')[0]), reverse=True)
        return finall





