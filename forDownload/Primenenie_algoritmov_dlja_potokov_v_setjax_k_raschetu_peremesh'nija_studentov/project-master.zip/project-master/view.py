import graph
import sys
from PyQt5.QtWidgets import QWidget, QPushButton, QApplication, QLabel, QGridLayout, QComboBox, QDesktopWidget

class Window(QWidget):

    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):

        grid = QGridLayout()
        self.setLayout(grid)

        grid.setSpacing(10)

        grid.setHorizontalSpacing(15)

        self.day = QComboBox(self)
        for line in graph.days:
            self.day.addItem(line)

        self.time = QComboBox(self)
        for line in graph.days_time:
            self.time.addItem(line)

        day_label = QLabel("День недели:", self)
        time_label = QLabel('Время:', self)
        str_label = QLabel('Пробки в ЛЭТИ', self)
        button_optimaze = QPushButton('Оптимизировать', self)
        button_search = QPushButton('Узнать', self)


        grid.addWidget(day_label, 0, 0)
        grid.addWidget(time_label, 0, 3)
        time_label.autoFillBackground()
        grid.addWidget(str_label, 2, 0)
        grid.addWidget(self.day, 0, 1)
        grid.addWidget(self.time, 0, 4)
        grid.addWidget(button_optimaze, 1, 3)
        grid.addWidget(button_search, 1, 4)

        names = ['','','Программа готова к работе','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','']
        positions = [(i, j) for i in range(3,10) for j in range(5)]

        self.label = []
        i = 0
        for position, name in zip(positions, names):
            self.label.append(QLabel(name))
            grid.addWidget(self.label[i], *position)
            i += 1

        button_search.clicked.connect(self.buttonClicked)
        button_optimaze.clicked.connect(self.button_optimazeClicked)

        self.center()
        self.setWindowTitle('ELTECH-GPS2017V0.1BETA')
        self.show()

    def bax(self,text):
        self.title.setText(text)
        self.title.adjustSize()

    def update(self, text, i):
        self.label[i].setText(text)
        self.label[i].adjustSize()

    def buttonClicked(self):
        s = 'graph.txt'

        tt = graph.Graph(self.day.currentText(), self.time.currentText())
        tt.list_node = tt.read_nodes_graph(s)
        tt.schedule = tt.read_schedule()
        a = tt.analysis_graph()
        for i in range(len(self.label)):
            try:
                self.update(a[i], i)
            except IndexError:
                self.update('', i)
        if len(a) == 0:
            self.update("Пробок в данное время нет", 2)

    def button_optimazeClicked(self):
        s = 'graph.txt'

        tt = graph.Graph(self.day.currentText(), self.time.currentText())
        tt.list_node = tt.read_nodes_graph(s)
        tt.schedule = tt.read_schedule()
        a = tt.optimization_graph()
        for i in range(len(self.label)):
            try:
                self.update(a[i], i)
            except IndexError:
                self.update('', i)
        if len(a) == 0:
            self.update("Пробок в данное время нет", 2)


    def center(self):
        qr = self.frameGeometry()
        cp = QDesktopWidget().availableGeometry().center()
        qr.moveCenter(cp)
        self.move(qr.topLeft())
        self.resize(1100,200)

if __name__ == '__main__':
    app = QApplication([])
    test = Window()
    sys.exit(app.exec_())
