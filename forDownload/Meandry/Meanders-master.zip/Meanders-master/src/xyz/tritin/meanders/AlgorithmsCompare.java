package xyz.tritin.meanders;

/**
 * @author Simon
 * @version 0.1
 *
 * Заготовка для сравнения алгоритмов
 */
public class AlgorithmsCompare {



}
