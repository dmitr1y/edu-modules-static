﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GraphGen
{
    class GraphMap
    {
        public int[] Map;
        public GraphMap(int[] map)
        {
            Map = new int[map.Length];
            map.CopyTo(Map, 0);
        }

        public override string ToString()
        {
            string s = "";
            foreach (int i in Map)
                s += i+" ";
            return s;
        }
    }

    static class ValidGraphs
    {
        public static List<GraphMap> Graphs;


        /// <summary>
        /// Вывести карту графа
        /// </summary>
        /// <param name="gr">Граф</param>
        public static void Print(GraphMap gr)
        {
            foreach (int i in gr.Map)
                Console.Write(i + " ");
            Console.WriteLine();
        }

        /// <summary>
        /// Вывести в консоль все карты графов
        /// </summary>
        public static void Print()
        {
            foreach (GraphMap gr in Graphs)
                Print(gr);
        }

        /// <summary>
        /// Рекурсивно генерирует графы
        /// </summary>
        /// <param name="arr">массив чисел, карта графа</param>
        /// <param name="offset">сдвиг</param>
        /// <returns></returns>
        static int[] Gen(int[] arr, int offset = 0)
        {

            if (offset + 1 < arr.Length)
            {
                while (true)
                {
                    bool wasLess = false;

                    for (int i = offset + 1; i < arr.Length; ++i)
                        if (arr[offset] - 1 > arr[i])
                        {

                            arr[offset]--;
                            arr[i]++;
                            Graphs.Add(new GraphMap(arr));
                            arr = Gen(arr, offset + 1);
                            wasLess = true;
                            break;
                        }
                    if (!wasLess)
                        return arr;
                }
            }
            //Console.ReadKey();
            return arr;

        }

        /// <summary>
        /// Генерирует все графы, удовлетворяющие условию
        /// </summary>
        /// <param name="k">доли</param>
        /// <param name="n">вершины</param>
        public static void Gen(int k, int n)
        {
            Graphs = new List<GraphMap>();


            int[] arr = new int[k];
            arr[0] = n - k + 1;
            for (int i = 1; i < k; ++i)
                arr[i] = 1;

            Graphs.Add(new GraphMap(arr));
            Gen(arr);
        }

        /// <summary>
        /// Возвращает граф с максимальным кол-вом ребер
        /// </summary>
        public static GraphMap GetMax()
        {
            return Graphs.Last();
        }

    }
}
