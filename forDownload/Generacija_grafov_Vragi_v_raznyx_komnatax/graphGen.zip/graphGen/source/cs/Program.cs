﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace GraphGen
{

    

    class Program
    {

        static void Main(string[] args)
        {
            Console.WriteLine("Генератор k-дольных графов на n вершинах \"Враги в разных комнатах\"\nЗадание к альтернативному экзамену Хаханова Тимофея, студента 6372 группы ФКТИ, 2017\n\n");
            while (true)
            {
                int k, n;
                while (true)
                {
                    Console.WriteLine("Введите кол-во долей: ");
                    if (Int32.TryParse(Console.ReadLine(), out k))
                    {
                        if (k > 1)
                            break;
                        else
                            Console.WriteLine("Число должно быть больше единицы");
                    }
                    else
                        Console.WriteLine("Ввод некорректен!");
                }

                while (true)
                {
                    Console.WriteLine("Введите кол-во вершин: ");
                    if (Int32.TryParse(Console.ReadLine(), out n))
                    {
                        if (n >= k)
                            break;
                        else
                            Console.WriteLine("Число должно быть больше/равно {0}", k);
                    }
                    else
                        Console.WriteLine("Ввод некорректен!");
                }

                var watch = Stopwatch.StartNew();

                ValidGraphs.Gen(k, n);

                watch.Stop();
                Console.WriteLine("Подобрано {1} графов за {0} миллисекунд!", watch.ElapsedMilliseconds, ValidGraphs.Graphs.Count);
                foreach (GraphMap G in ValidGraphs.Graphs)
                {

                    if (G.ToString() == ValidGraphs.Graphs.Last().ToString())
                        Console.WriteLine("Граф с максимальным числом ребер: ");
                    Console.WriteLine(G.ToString());
                }
                Console.WriteLine("\nПовторить?\n");
                Console.ReadLine();
            }
        }
    }
}
