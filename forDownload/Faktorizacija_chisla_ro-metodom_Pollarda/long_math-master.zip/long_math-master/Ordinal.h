#pragma once

// Результаты сравнений (меньше, больше, равно)
enum class Ordinal { LT = -1, GT = 1, EQ = 0 };
