#pragma once

enum class Signum { Zero = 0, Negative = 1, Positive = 2 };
