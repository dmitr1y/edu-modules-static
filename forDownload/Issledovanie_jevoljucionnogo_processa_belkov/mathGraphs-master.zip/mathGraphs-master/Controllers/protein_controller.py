
'''
author Egor Kolyshkin github EgorKolyshkin

class works with graphs and draw it on screen
'''

class protein_controller:

    def compare_proteins(self,protein1, protein2):
        dif = 0
        i = 0
        if (len(protein1.get_protein()) < len(protein2.get_protein())):
            min = len(protein1.get_protein())
        else:
            min = len(protein2.get_protein())
        for i in range(min-1):
            if(protein1.get_protein()[i] != protein2.get_protein()[i]):
                dif += 1
        dif += abs(len(protein1.get_protein()) - len(protein2.get_protein()))
        return dif

    def dif_proteins(self, proteins):
        i = g = 0
        count = len(proteins)
        for i in range(count):
            g = i + 1
            for g in range(count):
                proteins[i].get_diferences().insert(g ,self.compare_proteins(proteins[i], proteins[g]))

