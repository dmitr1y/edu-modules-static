import matplotlib.pyplot as plt
import networkx as nx
import numpy
from Controllers.file_controller import file_controller
from Controllers.protein_controller import protein_controller
from Controllers.algorithm_controller import algorithm_controller

'''
author Egor Kolyshkin github EgorKolyshkin

class works with graphs and draw it on screen
'''


class graph_controller:

    def __init__(self, filename):
        self.protein_controller = protein_controller()
        self.file_controller = file_controller()
        list = self.file_controller.parse_file(filename)
        self.protein_controller.dif_proteins(list)
        self.matrix = []
        for i in range (len(list[0].get_diferences())):
            self.matrix.append(list[i].get_diferences())
        self.algorithm_controller = algorithm_controller(self.get_matrix())

        N = numpy.matrix(self.matrix)
        self.graph = nx.from_numpy_matrix(N)
        b = self.algorithm_controller.build_tree()
        f = []
        self.chain = nx.Graph()
        for i in range(len(b) - 1):
            if i == 0:
                self.chain.add_node(b[i + 1])
                self.chain.add_edge("ROOT:" + str(b[i]), b[i + 1])
            else:
                self.chain.add_node(b[i])
                self.chain.add_node(b[i+1])
                self.chain.add_edge(b[i], b[i+1])
        self.tree = self.algorithm_controller.UPGMA_tree()

    def get_graph(self):
        return self.graph

    def get_chain(self):
        return self.chain
    def get_tree(self):
        return self.tree

    def get_matrix(self):
        return self.matrix

    def get_file_controller(self):
        return self.matrix

    def get_protein_controller(self):
        return self.matrix

    def set_matrix(self, matrix):
        self.matrix = matrix

    def set_file_controller(self, file_controller):
        self.file_controller = file_controller

    def set_protein_controller(self, protein_controller):
        self.protein_controller = protein_controller

    def get_algorithm_controller(self):
        return self.algorithm_controller

    def show_graph(self):
        pos = nx.shell_layout(self.graph)
        nx.draw_networkx(self.graph, pos = pos, node_size = 250, node_color = "#FA8072", edge_color = 'grey', font_size = 10)
        labels = nx.get_edge_attributes(self.graph, 'weight')
        nx.draw_networkx_edge_labels(self.graph, pos, edge_labels = labels, font_size = 8)
        plt.title("Graph")
        plt.show()

    def show_chain(self, text):
        plt.title("Tree")
        if text == "Spectral layout":
            pos = nx.spectral_layout(self.chain)
        elif text == "Circular layout":
            pos = nx.circular_layout(self.chain)
        else:
            pos = nx.fruchterman_reingold_layout(self.chain)
        nx.draw_networkx(self.chain, pos = pos, node_size = 250, node_color = "#FA8072", font_size = 10)
        plt.show()

    def show_tree(self):
        pos = nx.spring_layout(self.tree)
        nx.draw_networkx(self.tree, pos = pos, node_size = 250, node_color = "#FA8072", font_size = 10)
        plt.show()

    def kirgoph_centrality(self, gf):
        nodes = nx.betweenness_centrality(gf)
        string = ""
        for key, value in nodes.items():
            string += str(key) + " - " + str(value) + '\n'
        return string


    def get_names(self):
        return self.file_controller.pars_names()





