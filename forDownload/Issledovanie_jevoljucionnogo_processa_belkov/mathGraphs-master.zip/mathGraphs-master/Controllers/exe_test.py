from cx_Freeze import setup, Executable

setup(
    name = "M,j",
    version = "0.1",
    description = "Belki",
    executables = [Executable("start_window.py")]
)