from Model.protein import protein

'''
author Egor Kolyshkin github EgorKolyshkin

class works with files and parse it
'''

class file_controller:

    def get_file(self):
        return self.file

    def set_file(self, file):
        self.file = file

    def parse_file(self, way):
        i = 0
        list = []
        self.set_file(open(way,"r"))
        proteins = ""
        name = ""

        for line in self.get_file().readlines():
            if (line[0] == '>'):
                if (proteins != ""):
                    list.insert(i, protein(name, proteins))
                    i += 1
                proteins = ""
                name = line
                name = name[0:-1]
                name = name[1:]
            else:
                proteins += line
                proteins = proteins[0:-1]
        self.ls = list
        return list

    def pars_names(self):
        j = 0
        string = ""
        for i in self.ls:
            string +=str(j) + " - " + i.get_name() + '\n'
            j += 1
        return string
