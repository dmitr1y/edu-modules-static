import networkx as nx
import copy
import time
'''
author Atroshenko Yaroslav github yaroslavok

class works with algorithms on graphs
'''


class algorithm_controller:

    def __init__(self, matrix):
        self.matrix = matrix

    def build_tree(self):
        a = []
        b = []
        k = len(self.matrix[0])
        for i in range(k):
            sum = 0
            for j in range(k):
                # sum += self.matrix[i][j]
                sum += self.FLOYD()[i][j];
            a.append(sum)
            b.append(i)
        n = 1
        while n < k:
            for i in range(k - n):
                if a[i] < a[i + 1]:
                    a[i], a[i + 1] = a[i + 1], a[i]
                    b[i], b[i + 1] = b[i + 1], b[i]
            n += 1
        return b

    def min_weight(self, matrix):


        min = float("inf")
        x, y = 0, 0

        for i in range(len(matrix)):
            for j in range(len(matrix[i])):
                if matrix[i][j] < min and matrix[i][j] != 0 and j > i:
                    min = matrix[i][j]
                    x, y = i, j

        return x, y


    def join_matrix(self, matrix, a, b):
        if b < a:
            a, b = b, a
        for i in range(0, len(matrix)):
            matrix[i][a] = (matrix[i][a] + matrix[i][b]) / 2
            del matrix[i][b]

        del matrix[b]

    def code_index(self, len, index):
        if index < len:
            return "P"+str(index)
        else:
            if index == 2 * len - 2:
                return "ROOT"
            else:
                return "C"+str(index-(len))

    def UPGMA_tree(self):
        print(self.matrix)
        dict = []
        ln = len(self.matrix[0])
        for i  in range (ln):
            dict.append(i)
        matrix = copy.deepcopy(self.matrix)
        G = nx.Graph()
        j = 0
        while len(matrix) > 1:
            x, y = self.min_weight(matrix)
            self.join_matrix(matrix, x, y)
            y = dict.pop(y)
            try:
                G.add_node(self.code_index(ln,dict[x]))
                G.add_edge(self.code_index(ln,ln + j),self.code_index(ln,dict[x]))
                dict[x] = ln + j
            except IndexError:
                pass
            G.add_node(self.code_index(ln,y))
            G.add_edge(self.code_index(ln,ln + j),self.code_index(ln,y))
            j += 1
        return G

    def BinSearch(self, li, x):
        i = 0
        j = len(li) - 1
        m = int(j / 2)
        while (li[m] != x) and (i < j):
            if (x > li[m]):
                i = m + 1
            else:
                j = m - 1
            m = int((i + j) / 2)
        if (i > j):
            return "No such elem"
        else:
            return m

    '''
    author Egor Kolyshkin github EgorKolyshkin

    func algorithm Dijkstra
    '''

    def Dijkstra(self, S):
        N = len(self.matrix)
        valid = [True] * N
        weight = [1000000] * N
        weight[S] = 0
        for i in range(N):
            min_weight = 1000001
            ID_min_weight = -1
            for i in range(len(weight)):
                if valid[i] and weight[i] < min_weight:
                    min_weight = weight[i]
                    ID_min_weight = i
            for i in range(N):
                if weight[ID_min_weight] + self.matrix[ID_min_weight][i] < weight[i]:
                    weight[i] = weight[ID_min_weight] + self.matrix[ID_min_weight][i]
            valid[ID_min_weight] = False
        string = ""
        g = 0
        for i in weight:
            string = string + str(i) + ' '
            g += 1
        return string + '\n'

    def FLOYD (self):
        matrix = self.matrix
        N = len(matrix)
        for i in range (N + 1):
            for j in range (N - 1):
                for k in range (N - 1):
                    if matrix[j][k] > matrix[j][i - 1] + matrix[i - 1][k]:
                        matrix[j][k] = matrix[j][i - 1] + matrix[i - 1][k]
        return matrix

    def floyd(self, num):
        tmp1 = time.time()
        if num < 0:
            string = self.matrix_to_str(self.FLOYD())
        else:
            string = self.line_to_str(self.FLOYD()[num])
        tmp2 = time.time()
        return string + '\n time: ' + str(tmp2 - tmp1)

    def line_to_str(self, arr):
        string = ""
        for i in arr:
            string = string + str(i) + ' '
        string += '\n'
        return string

    def matrix_to_str(self, matrix):
        str = ""
        for i in range (len(matrix)):
            str += self.line_to_str(matrix[i])
        return str

    def matrix_dijcstra(self):
        tmp1 = time.time()
        N = len(self.matrix)
        string = ""
        for i in range (N):
            string += self.Dijkstra(i)
        tmp2 = time.time()
        return string + '\n time: ' + str(tmp2 - tmp1)
