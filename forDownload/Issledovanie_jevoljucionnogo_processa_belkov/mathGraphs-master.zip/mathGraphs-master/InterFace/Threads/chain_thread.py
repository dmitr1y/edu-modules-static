import threading

'''
author Atroshenko Yaroslav github yaroslavok

class run new thread when user press btn show tree
'''

class chain_thread(threading.Thread):
    def __init__(self, gf, btn1, btn2, text):
        threading.Thread.__init__(self)
        self.daemon = True
        self.gf = gf
        self.btn1 = btn1
        self.btn2 = btn2
        self.text = text

    def run(self):
        self.gf.show_chain(self.text)
        self.btn1.setEnabled(True)
        self.btn2.setEnabled(True)
