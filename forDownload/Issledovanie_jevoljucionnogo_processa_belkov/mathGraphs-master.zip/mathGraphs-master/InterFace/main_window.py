import sys

from PyQt5.QtWidgets import QWidget, QPushButton, QLineEdit, QVBoxLayout, QHBoxLayout, QApplication, QLabel, QComboBox

from Controllers.graph_controller import graph_controller
from InterFace.Threads.graph_thread import graph_thread
from InterFace.Threads.chain_thread import chain_thread
from InterFace.Threads.tree_thread import tree_thread
from InterFace.info_window import info_window

'''
author Atroshenko Yaroslav github yaroslavok

class draws main-window
'''

class main_window(QWidget):
    def __init__(self, filename):
        self.gf = graph_controller(filename)
        super().__init__()
        self.initUI()



    def initUI(self):
        self.min_way_label = QLabel("Dijkstra algorithm")
        self.bin_search_label = QLabel("Floyd algorithm")
        self.info = None
        self.show_tree_btn = QPushButton("Show Tree")
        self.show_chain_btn = QPushButton("Show Chain")
        self.show_graph_btn = QPushButton("Show Graph")
        self.show_info_btn = QPushButton("Show Info")
        self.edges_centrality_btn = QPushButton("Nodes centrality")
        self.floyd_edit = QLineEdit()
        self.min_way_search_edit = QLineEdit()
        self.compare_nodes_edit = QLineEdit()
        self.floyd_btn = QPushButton("Floyd")
        self.min_way_search_btn = QPushButton("Dijcstra")
        self.choose_layout_label = QLabel("Choose chain show layout")
        self.choose_layout_combobox = QComboBox()
        self.choose_layout_combobox.addItem("Spectral layout")
        self.choose_layout_combobox.addItem("Circular layout")
        self.choose_layout_combobox.addItem("Fruchterman layout")

        main_box = QVBoxLayout()
        show_btns_hbox_layout = QHBoxLayout()
        floyd_hbox_layout = QHBoxLayout()
        min_way_search_hbox_layout = QHBoxLayout()
        show_tree_layout = QHBoxLayout()
        choose_layout_hbox_layout = QHBoxLayout()

        show_btns_hbox_layout.addWidget(self.show_info_btn)
        show_btns_hbox_layout.addWidget(self.edges_centrality_btn)
        floyd_hbox_layout.addWidget(self.floyd_edit)
        floyd_hbox_layout.addWidget(self.floyd_btn)
        min_way_search_hbox_layout.addWidget(self.min_way_search_edit)
        min_way_search_hbox_layout.addWidget(self.min_way_search_btn)
        show_tree_layout.addWidget(self.show_graph_btn)
        show_tree_layout.addWidget(self.show_tree_btn)
        show_tree_layout.addWidget(self.show_chain_btn)
        choose_layout_hbox_layout.addStretch(10)
        choose_layout_hbox_layout.addWidget(self.choose_layout_label)
        choose_layout_hbox_layout.addWidget(self.choose_layout_combobox)

        main_box.addWidget(self.bin_search_label)
        main_box.addLayout(floyd_hbox_layout)
        main_box.addStretch(10)
        main_box.addWidget(self.min_way_label)
        main_box.addLayout(min_way_search_hbox_layout)
        main_box.addStretch(10)
        main_box.addLayout(show_tree_layout)
        main_box.addLayout(choose_layout_hbox_layout)
        main_box.addStretch(10)
        main_box.addLayout(show_btns_hbox_layout)

        self.setLayout(main_box)
        self.setGeometry(110, 100, 500, 300)
        self.setWindowTitle('Proteins')
        self.show()

        self.show_graph_btn.clicked.connect(self.show_graph_btn_clicked)
        self.show_info_btn.clicked.connect(self.show_info_btn_clicked)
        self.min_way_search_btn.clicked.connect(self.min_way_search_btn_clicked)
        self.show_chain_btn.clicked.connect(self.show_chain_btn_clicked)
        self.edges_centrality_btn.clicked.connect(self.edges_centrality_btn_clicked)
        self.show_tree_btn.clicked.connect(self.show_tree_btn_clicked)
        self.floyd_btn.clicked.connect(self.floyd_btn_clicked)


    def show_graph_btn_clicked(self):
        try:
            self.graph_thread = graph_thread(self.gf, self.show_tree_btn, self.show_chain_btn)
            self.graph_thread.setName("graph_thread")
            self.graph_thread.start()
            self.show_tree_btn.setEnabled(False)
            self.show_chain_btn.setEnabled(False)
        except RuntimeError:
            return

    def show_info_btn_clicked(self):
        if (self.info == None) or (self.info.isVisible() == 0):
            self.info = info_window()
        self.info.set_text(self.gf.get_names())

    def min_way_search_btn_clicked(self):
        matrix_len = len(self.gf.get_matrix())
        tmp = matrix_len + 1
        if (self.info == None) or (self.info.isVisible() == 0):
            self.info = info_window()
        if self.min_way_search_edit.text() == "all":
            self.info.set_text(self.gf.get_algorithm_controller().matrix_dijcstra())
            return
        try:
            tmp = int(self.min_way_search_edit.text())
        except ValueError:
            print("Value error")
        if tmp >= matrix_len:
            self.info.set_text("This node is not exist")
        else:
            self.info.set_text(self.gf.get_algorithm_controller().Dijkstra(tmp))


    def show_chain_btn_clicked(self):
        try:
                self.chain_thread = chain_thread(self.gf, self.show_graph_btn, self.show_tree_btn, self.choose_layout_combobox.currentText())
                self.chain_thread.setName("tree_thread")
                self.chain_thread.start()
                self.show_graph_btn.setEnabled(False)
                self.show_tree_btn.setEnabled(False)
        except RuntimeError:
            return

    def show_tree_btn_clicked(self):
        try:
            self.tree_thread = tree_thread(self.gf, self.show_graph_btn, self.show_chain_btn)
            self.tree_thread.setName("tree_thread")
            self.tree_thread.start()
            self.show_graph_btn.setEnabled(False)
            self.show_chain_btn.setEnabled(False)
        except RuntimeError:
            return

    def edges_centrality_btn_clicked(self):
        if (self.info == None) or (self.info.isVisible() == 0):
            self.info = info_window()
        self.info.set_text(self.gf.kirgoph_centrality(self.gf.get_tree()))

    def floyd_btn_clicked(self):
        matrix_len = len(self.gf.get_matrix())
        if (self.info == None) or (self.info.isVisible() == 0):
            self.info = info_window()
        if self.floyd_edit.text() == "all":
            tmp = -1
        else:
            try:
                tmp = int(self.floyd_edit.text())
            except ValueError:
                print("Value error")
                return
        if tmp >= matrix_len:
            self.info.set_text("This node is not exist")
        else:
            self.info.set_text(self.gf.get_algorithm_controller().floyd(tmp))

if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = main_window()
    sys.exit(app.exec_())

