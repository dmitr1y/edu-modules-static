import sys
from PyQt5.QtWidgets import QWidget, QLineEdit, QLabel, QPushButton, QHBoxLayout, QVBoxLayout, QApplication, QFileDialog
from PyQt5.QtGui import QFont
from InterFace.main_window import main_window
import os

'''
author Atroshenko Yaroslav github yaroslavok

class draws start-window, start point of the programm
'''



class start_window(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):

        TEXT = "Эта программа разработана для визуализации и анализа \nфилогенетического дерева,составленной из белков." \
               "Также реализованы\nнекоторые алгоритмы над графом, составленным из этих белков.\n" \
               "\n\nАвторы : студенты ФКТИ СПБГЭТУ ЛЭТИ гр. 6306 \n" \
               "Атрошенко Ярослав и Егор Колышкин "

        FONT = QFont("Arial", 12)

        self.file_label = QLabel("Enter the way to file")
        self.start_label = QLabel(TEXT, self)
        self.start_label.setFont(FONT)
        self.file_reader_edit_line = QLineEdit()
        self.file_reader_button = QPushButton("...")
        self.start_button = QPushButton("Start")

        vbox = QVBoxLayout()
        file_reader_hboxlayout = QHBoxLayout()
        text_hbox_layout = QHBoxLayout()
        start_hbox_layout = QHBoxLayout()

        file_reader_hboxlayout.addWidget(self.file_reader_edit_line)
        file_reader_hboxlayout.addWidget(self.file_reader_button)
        start_hbox_layout.addStretch(12)
        start_hbox_layout.addWidget(self.start_button)
        start_hbox_layout.addStretch(1)
        text_hbox_layout.addWidget(self.start_label)
        text_hbox_layout.addStretch(1)

        vbox.addLayout(text_hbox_layout)
        vbox.addStretch(10)
        vbox.addWidget(self.file_label)
        vbox.addLayout(file_reader_hboxlayout)
        vbox.addStretch(3)
        vbox.addLayout(start_hbox_layout)

        self.file_reader_button.clicked.connect(self.file_reader_button_clicked)
        self.start_button.clicked.connect(self.start_button_clicked)

        self.setLayout(vbox)
        self.setGeometry(300, 300, 500, 300)
        self.setWindowTitle('Start Graph')
        self.show()

    def file_reader_button_clicked(self):
        self.file_reader_edit_line.setText(QFileDialog.getOpenFileName(self, "Open file")[0])

    def start_button_clicked(self):
        if os.path.exists(self.file_reader_edit_line.text()):
            self.main_window = main_window(self.file_reader_edit_line.text())
            self.close()
        else:
            self.file_reader_edit_line.setText("File is not exist")



if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = start_window()
    sys.exit(app.exec_())

