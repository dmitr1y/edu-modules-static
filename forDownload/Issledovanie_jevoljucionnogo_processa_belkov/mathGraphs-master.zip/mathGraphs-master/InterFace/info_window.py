import sys
from PyQt5.QtWidgets import QTextEdit, QHBoxLayout, QWidget, QApplication

'''
author Egor Kolyshkin github EgorKolyshkin

class draw info-window and show the information
'''


class info_window(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.text_info = QTextEdit()
        self.text_info.setReadOnly(True)
        main_box = QHBoxLayout()
        main_box.addWidget(self.text_info)

        self.setLayout(main_box)
        self.setGeometry(110, 430, 600, 200)
        self.setWindowTitle('INFO')
        self.show()

    def set_text(self, str):
        self.text_info.setText(str)

    def get_text(self):
        return self.text_info.text()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = info_window()
    sys.exit(app.exec_())

