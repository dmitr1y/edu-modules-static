'''
author Atroshenko Yaroslav github yaroslavok

main model class
'''


class protein:

    def __init__(self, name, protein):
        self.name = name
        self.protein = protein
        self.diferences = []

    def get_diferences(self):
        return self.diferences

    def get_name(self):
        return self.name

    def get_protein(self):
        return self.protein

    def set_name(self, name):
        self.name = name

    def set_protein(self, protein):
        self.protein = protein

    def set_diferences(self, diferences):
        self.diferences = diferences
