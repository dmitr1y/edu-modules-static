library(frbs);

data1 <- read.csv(file = "TrainData.csv", header = FALSE);

data2 <- read.csv(file = "NewData.csv", header = FALSE);

n <- dim(data1)[1];
m <- dim(data1)[2];
data1 <- as.matrix(data1);
result <- c();

for (i in 1:n)
{
  for (j in 1:m)
  {
    if(data1[i,j] != "-") 
    {
      result <- c(result, j, i, data1[i,j]);
    }
  }
}

z <- as.numeric(result);

data.train <- matrix(z, ncol = 3, byrow = TRUE);

data2 <- as.matrix(data2);

range.data<-matrix(c(1, m, 1, n, 0, 1), ncol=3, byrow = FALSE);

if ((n<4) && (m<4)) {
  method.type <- "WM"
  control <- list(num.labels = 3, type.mf = "GAUSSIAN", type.tnorm = "MIN",
                  type.snorm = "MAX", type.defuz = "WAM",
                  type.implication.func = "ZADEH", name = "Sim-0");
} else {
  method.type <- "SBC"
  control <- list(r.a = 0.15, eps.high = 1, eps.low = 0, name ="Sim-0");
}

object <- frbs.learn(data.train, range.data, method.type, control);

res <- predict(object, data2);

write.table(res, file = "output.csv", col.names = FALSE, row.names = FALSE);
